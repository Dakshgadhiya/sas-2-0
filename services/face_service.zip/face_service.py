import base64
import numpy as np
import cv2
import face_recognition
from backend import config


def decode_image(data_url):
    if "," in data_url:
        data_url = data_url.split(",", 1)[1]
    img_bytes = base64.b64decode(data_url)
    img_array = np.frombuffer(img_bytes, dtype=np.uint8)
    return cv2.imdecode(img_array, cv2.IMREAD_COLOR)


def encode_face_from_image(image):
    rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    boxes = face_recognition.face_locations(rgb)
    if not boxes or len(boxes) != 1:
        return None
    encodings = face_recognition.face_encodings(rgb, boxes)
    if not encodings:
        return None
    return encodings[0]


def encode_face_from_images(image_list):
    encodings = []
    for img in image_list:
        encoding = encode_face_from_image(img)
        if encoding is not None:
            encodings.append(encoding)
    if not encodings:
        return None
    return np.mean(encodings, axis=0)


def serialize_encoding(encoding):
    return encoding.astype(np.float32).tobytes()


def deserialize_encoding(blob):
    return np.frombuffer(blob, dtype=np.float32)


def compare_faces(stored_encoding, captured_encoding, tolerance=0.45):
    if stored_encoding is None or captured_encoding is None:
        return False, None, tolerance
    distance = face_recognition.face_distance([stored_encoding], captured_encoding)[0]
    return distance <= tolerance, float(distance), tolerance
